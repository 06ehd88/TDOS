# TR-KAS-2026-07 Kastamonu Reference Mission

## Status

Reference-mission engineering input.

## Intended use

Mission reports, observations and lessons learned are evidence sources. They are not canonical Development Simulator inputs until normalized into TECR.

## Main learning areas

- Runtime decisions versus static planning
- Evidence quality
- Explicit unknown handling
- Detection versus verification
- Operational logistics
- Parking and walking-start separation
- Decision delivery
- Runtime traceability
- Mission completion and replay
