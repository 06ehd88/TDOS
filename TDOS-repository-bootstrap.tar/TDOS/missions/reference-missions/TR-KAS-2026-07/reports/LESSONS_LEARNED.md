# Kastamonu Reference Mission Lessons Learned

- Runtime decisions can dominate static planning.
- Evidence quality determines recommendation quality.
- Unknown information shall remain unknown until verified.
- Detection and verification are separate engineering activities.
- Planning and runtime outputs serve different purposes.
- Runtime event timestamps can become engineering evidence.
- Canonical place names reduce navigation ambiguity.
- Operational logistics are required for executable missions.

These lessons require evidence review and FIP evaluation before integration.
