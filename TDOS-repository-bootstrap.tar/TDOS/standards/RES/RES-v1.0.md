# Runtime Evidence Standard (RES) v1.0

## Status

Accepted Runtime Engineering Standard

## Core rules

- Missing factual evidence shall not be replaced with assumptions.
- Unknown remains UNKNOWN until verified.
- Evidence, interpretation and recommendation shall remain separate.
- Every recommendation shall expose evidence, source, confidence and verification status.
- Community sources may adjust confidence but shall not override verified official guidance.
- Google Maps links shall not be fabricated.

## Evidence classifications

- Official Verified
- Operationally Verified
- User Verified
- Community Validated
- Derived
- Not Verified
- Unknown
