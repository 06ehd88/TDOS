# Development Simulator Operating Standard (DSOS) v1.0

## Status

Draft Operating Standard

## Purpose

Defines how the TDOS Development Simulator operates. It creates no architecture, governance, modules or capabilities.

## Canonical input rule

The current approved TR Engineering Candidate Registry (TECR) is the sole canonical candidate input.

Raw reference-mission reports, lessons learned, candidate packs and engineering notes shall first be normalized into TECR.

## Session startup

1. Load the current Engineering Baseline Set.
2. Confirm AB-6.0-001.
3. Confirm current TESP, DSOS, FIP, TECR and REII versions.
4. Mark unavailable downstream artifacts accurately.
5. Synchronize to the latest approved TECR.
6. Select normalized Candidate IDs.

## Session workflow

```text
Baseline Loading
  -> Registry Synchronization
  -> Candidate Selection
  -> Controlled Asset Discovery
  -> FIP Evaluation
  -> RQC Assessment
  -> Governance Compatibility Check
  -> REII Routing
  -> Engineering Recommendation
  -> Session Report
  -> Registry Update Actions
  -> Session Closure
```

## Mandatory outputs

- Engineering Session Report
- Candidate decisions and rationale
- Controlled asset mapping
- Risks and open questions
- Registry Update Actions

The simulator shall not directly modify TECR or authorize engineering changes.
