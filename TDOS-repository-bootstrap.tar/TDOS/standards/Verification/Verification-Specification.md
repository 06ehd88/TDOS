# TDOS Verification Specification

## Status

NOT STARTED

## Planned verification levels

### Architecture verification

- Architecture Integration Assessment
- Architecture Conformance Assessment

### Runtime verification

- CSC conformance
- JSON Schema conformance
- Module Runtime Contract conformance
- RQC conformance

### Operational verification

- Reference Mission execution
- Runtime trace
- Mission artifacts
- F13 operational evidence

## Minimum test-case fields

- Test ID
- Governing requirement
- Input
- Expected behaviour
- Acceptance criteria
- Evidence source
- Result
