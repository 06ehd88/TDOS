# Runtime Quality Criteria

## Status

Frozen Evaluation Criteria

| ID | Criterion | Objective |
|---|---|---|
| RQC-01 | Determinism | Equivalent inputs produce equivalent runtime semantics |
| RQC-02 | Completeness | Required behavioural elements are defined |
| RQC-03 | Ambiguity | Independent implementations reach the same semantic interpretation |
| RQC-04 | Traceability | Behaviour is attributable to governing assets |
| RQC-05 | Implementability | No undocumented architectural assumptions are required |
| RQC-06 | Verifiability | Behaviour has objective evidence and acceptance criteria |

Governance compatibility is a separate check and is not an additional RQC.
