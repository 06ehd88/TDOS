# Canonical Signal Contract (CSC) v1.0

## Status

WORKING DRAFT

## Baseline

AB-6.0-001

## Semantic authority

CSC defines Canonical Signal meaning independently from serialization and implementation.

## Approved conceptual areas

1. Document Control
2. Purpose and Scope
3. Architecture Position
4. Governance
5. Canonical Signal Model
6. Signal Lifecycle
7. Mandatory Fields
8. Field Semantics
9. Enumerations

## Validation section status

Section 10 requires rework before approval. Blocking issues include:

- Validation shall not make F11 a system-wide ingress gateway.
- The validation rule set shall cover the complete CSC model.
- `authority_confidence` writer authority shall be resolved in Section 12 and Runtime Contracts.
- Neutral pre-validated failure signals shall not bypass validation.
- Operational alert severity shall remain separate from validation failure.
- TTL semantics shall be governed by Section 11.

## Planned sections

10. Validation Rules
11. TTL Semantics
12. Authority and Confidence
13. Provenance Rules
14. Veto Dimension Rules
15. Serialization Independence
16. Compatibility Rules
17. Versioning Policy
18. Change Management
19. Governance Requirements
20. Conformance Criteria
21. Appendices

## Core invariants

- One Canonical Signal represents one semantic concept.
- Semantic meaning is implementation independent.
- Semantic meaning is serialization independent.
- Every signal is traceable and objectively verifiable.
- Downstream artifacts shall not redefine CSC semantics.
