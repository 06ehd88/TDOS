# Runtime Artifacts

Planned runtime artifacts include:

- Mission Card
- Decision Card
- Operational Waypoint Card
- Operational Timeline
- Navigation Artifact
- Mission Completion Report

Runtime artifacts present approved runtime semantics. They shall not contain independent decision logic.
