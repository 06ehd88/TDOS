# F07 Module Runtime Contract

## Status

NOT STARTED

## Required sections

- Module identity and owner
- Inputs
- Outputs
- Preconditions
- Postconditions
- Execution order
- Failure behaviour
- Recovery behaviour
- TTL handling
- Confidence handling
- Veto handling, if applicable
- Traceability references
- Verification criteria

This contract shall be authored only after CSC and Canonical Signal JSON Schema approval.
