# TDOS Engineering Governance Flow

```text
Engineering Evidence
  -> Candidate Recommendation
  -> Runtime Review
  -> Architecture Review, if required
  -> Authorized Decision
  -> Controlled Integration
```

Simulator output is not an authorized decision.

## Processes

- Architecture Integration Assessment
- Architecture Conformance Assessment

## Gates

- Architecture Review
- Integration Review
- Alpha Freeze Validation
- Implementation Readiness Review
