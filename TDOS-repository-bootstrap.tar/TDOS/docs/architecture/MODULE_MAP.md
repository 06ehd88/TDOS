# TDOS Module Map

| ID | Module | Primary responsibility |
|---|---|---|
| F01 | Decision Engine | Sole operational decision authority |
| F02 | Weather Engine | Weather intelligence and operational effects |
| F03 | Transport Engine | Transport options, disruptions and connection risks |
| F04 | Route Engine | Route construction and sequencing |
| F05 | Risk Engine | Risk assessment and veto-condition production |
| F06 | Festival Engine | Event and festival intelligence |
| F07 | Waypoint Engine | Canonical waypoint representation |
| F08 | Photo Engine | Photography opportunity intelligence |
| F09 | Operational Awareness / Logistics | Approved-mission execution support |
| F10 | Learning Engine | Runtime evidence learning preparation |
| F11 | Mission Card Generator | Decision-centric runtime presentation |

## Decision authority

Only F01 produces GO, GO_WITH_CAUTION, LIMITED_OPERATIONS, HOLD or NO_GO decisions.
