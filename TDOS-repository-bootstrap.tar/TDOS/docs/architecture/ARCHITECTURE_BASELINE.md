# TDOS Architecture Baseline

## Baseline ID

AB-6.0-001

## State

FROZEN

## Baseline scope

- Approved architecture principles
- Accepted ADRs
- F01-F11 module boundaries
- Capability Registry
- Capability Traceability Matrix
- Module Specifications MS-00 through MS-11

## Protection rule

No baseline modification shall occur without an approved architecture decision and the required governance review.
