# TDOS Engineering Baseline Set

## Status

Configuration definition for Development Sessions.

## Required assets

1. TDOS Engineering Starter Pack
2. Development Simulator Operating Standard
3. Feature Integration Playbook
4. Current TECR
5. Runtime Engineering Integration Interface
6. Current CSC
7. Current Canonical Signal JSON Schema
8. Current Module Runtime Contracts
9. Current Verification Specification
10. Current Reference Implementation

Unavailable assets shall be marked `NOT AVAILABLE` or `NOT STARTED`; they shall not be invented.
