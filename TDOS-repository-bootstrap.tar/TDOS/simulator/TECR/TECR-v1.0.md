# TR Engineering Candidate Registry (TECR) v1.0

## Status

INITIAL NORMALIZATION SEED

TECR is the sole canonical candidate input for the TDOS Development Simulator.

| Candidate ID | Canonical title | Category | Origin | Priority | Preferred target | Status |
|---|---|---|---|---|---|---|
| TRK-001 | Verified Official Destination Guidance | Runtime behaviour | TR-KAS-2026-07 | P0 | F09 Runtime Contract | Registered |
| TRK-002 | Operational Logistics Intelligence | Runtime behaviour | TR-KAS-2026-07 | P0 | F09 Runtime Contract | Registered |
| TRK-003 | Google Maps Integrity | Runtime standard | TR-KAS-2026-07 | P0 | Verification / F09 / Mission Artifact | Registered |
| TRK-004 | Provider Authority Hierarchy | Runtime standard | TR-KAS-2026-07 | P0 | Verification Specification | Registered |
| TRK-005 | Evidence Classification and Unknown Handling | Runtime standard | TR-KAS-2026-07 | P0 | RES / Verification | Registered |
| TRK-006 | Decision Context Information Selection | Runtime artefact behaviour | TR-KAS-2026-07 | P1 | F11 Runtime Contract | Registered |
| TRK-007 | Runtime Artifact Standardization | Runtime artefact | TR-KAS-2026-07 | P1 | F11 / Reference Implementation | Registered |
| TRK-008 | Parking and Walking-Start Separation | Runtime behaviour | TR-KAS-2026-07 | P0 | F07/F09 Contracts | Registered |
| TRK-009 | Detection and Verification Separation | Verification behaviour | TR-KAS-2026-07 | P0 | Verification Specification | Registered |
| TRK-010 | Runtime Evidence Workflow | Engineering infrastructure | TR-KAS-2026-07 | P0 | DSOS / REII | Registered |
| TRK-011 | Controlled Asset Impact Analysis | Engineering infrastructure | TR-KAS-2026-07 | P0 | FIP / REII | Registered |
| TRK-012 | Mission Completion Report | Runtime artefact | TR-KAS-2026-07 | P1 | Reference Implementation | Deferred |
| TRK-013 | Mission Replay | Future runtime capability | TR-KAS-2026-07 | P1 | Future release | Deferred |
| TRK-014 | Golden Mission Regression | Verification infrastructure | TR-KAS-2026-07 | P1 | Verification Specification | Deferred |
| TRK-015 | Runtime Trust Preparation | Engineering preparation | TR-KAS-2026-07 | P1 | Future authorization | Deferred |

## Normalization rule

Raw candidate packs shall not be evaluated directly. Duplicate proposals shall be merged into one canonical Candidate ID while preserving all evidence references.
