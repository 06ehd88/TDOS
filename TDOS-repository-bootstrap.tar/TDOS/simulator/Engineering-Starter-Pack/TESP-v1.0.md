# TDOS Engineering Starter Pack (TESP) v1.0

## Status

Engineering Onboarding Specification

## Purpose

Provides the minimum authoritative context required to start a TDOS Development Session while preserving AB-6.0-001.

## Current phase

Runtime Engineering.

## Mandatory session standards

- DSOS: simulator operating order
- TECR: sole canonical candidate input
- FIP: sole evaluation standard
- REII: controlled integration routing
- RQC: fixed runtime-quality evaluation criteria

## Current canonical work package

1. CSC v1.0
2. Canonical Signal JSON Schema v1.0
3. Module Runtime Contracts F01-F11
4. Verification Specification
5. Reference Implementation

## Critical rule

CSC defines semantics. JSON Schema represents semantics. Runtime Contracts define module behaviour. Implementation follows approved contracts.
